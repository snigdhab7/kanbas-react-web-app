import React from "react";
import { Link, useParams } from "react-router-dom";
import db from "../../Database";
import "../../../lib/bootstrap/bootstrap.css"
import "../../../lib/font-awesome/css/font-awesome.css"
import "../../../styles.css"
import { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
addAssignment,
deleteAssignment,
updateAssignment,
setAssignment,
} from "C:/Users/Lenovo/2023/fall/webdev/kanbas-react-web-app/src/Kanbas/Courses/Assignments/assignmentsReducer.js";

function Assignments() {
const { courseId } = useParams();
const { assignmentId } = useParams();

const assignments = useSelector((state) => state.assignmentsReducer.assignments);
const [assignment, setAssignment] = useState(assignments.find((assignment) => assignment._id === Number(assignmentId)));
//const assignment = useSelector((state) => state.assignmentsReducer.assignment);
/* const courseAssignments = useSelector((state) => state.assignmentsReducer.assignment.filter(
    (assignment) => assignment.course === courseId));
const dispatch = useDispatch(); */
const dispatch = useDispatch();
console.log("courseid",assignments)
//const assignments = db.assignments;
const courseAssignments = assignments.filter(
(assignment) => assignment.course === courseId);
return (

<>
    <br/><br/>
    
         <div className="row" style={{width:'90%'}}>
        <nav style={{flexDirection: 'row', paddingLeft: '10px'}}>
                    <form className="form-group">
        <div className="d-flex justify-content-between">
                            <div>
                                <input className="form-control me-2 float-start" type="search" placeholder="Search for Assignment" aria-label="Search"></input>
                            </div>
                            <div>
                                <button className="btn btn-light btn-outline-secondary" style={{marginRight: '5px'}}type="submit">+ Group</button>
                                <Link to="/Kanbas/Courses" className="btn btn-light btn-outline-secondary wd-select-button" style={{ marginRight: '5px' }}>
        + Assignment
      </Link>
                                     <button className="btn btn-light btn-outline-secondary" type="submit"><i className="fa fa-ellipsis-v" aria-hidden="true"></i></button>
                            </div>
                        </div>
                        </form>   
                </nav>
                <br/><br/>
                <div className="wd-flex-grow-1 ">

            <ul className="list-group">
            <li className="list-group-item">
             <button onClick={() => dispatch(addAssignment({ ...assignment, course: courseId }))}>
    Add</button>
    <button onClick={() => dispatch(updateAssignment(assignment))}>
    Update
</button>
<input type="text" value={assignments.title} onChange={(e) => setAssignment({ ...assignment, title: e.target.value })} />
<textarea value={assignments.description} onChange={(e) => setAssignment({ ...assignment, description: e.target.value })} />


</li>
                <div className="list-group-item list-group-item-heading d-flex justify-content-between align-items-center" style={{ marginBottom: '30px', backgroundColor: ' #ececec'}}>

                    <div>
                        <i className="fa fa-ellipsis-v" style={{paddingLeft:'3px'}} aria-hidden="true"></i><i className="fa fa-ellipsis-v" style={{ paddingRight: '10px'}} aria-hidden="true"></i>
                        <i className="fa fa-caret-down" style={{paddingRight :'10px'}} aria-hidden="true"></i>
                        <b>Assignments</b>
                    </div>
                    <div style={{width: '200px'}}>
                        <button className="assignment-button" style={{marginRight: '5px'}}>40% of total</button>
                        <i className="fa fa-plus wd-padding-20-right"  style={{marginRight: '5px'}} aria-hidden="true"></i>
                        <i className="fa fa-ellipsis-v wd-padding-20-right"  style={{marginRight: '5px'}} aria-hidden="true"></i>
                    </div>
    
                </div>    
                 
                {courseAssignments.map((assignment) => (
                   
                <Link
key={assignment._id}
to={`/Kanbas/Courses/${courseId}/Assignments/${assignment._id}`}
className="list-group-item d-flex justify-content-between align-items-center">

<div ><button onClick={() => dispatch(deleteAssignment(assignment._id))}>Delete</button>
                        <i className="fa fa-ellipsis-v" style={{paddingLeft:'2px'}} aria-hidden="true"></i><i className="fa fa-ellipsis-v" aria-hidden="true"></i>
                        <i className="fa fa-pencil-square-o wd-icon-green" style={{paddingLeft:'5px'}}  aria-hidden="true"></i>
                    </div>
                    <div>
                        <div className="fs-5">{assignment.title}</div>
                        <div className="fw-light">{assignment.description}</div>
                        <div className="fw-light">{assignment.dueDate}</div>
                    </div>
                    <div>
                        <i className="fa fa-check-circle wd-icon-green wd-padding-20-right"  style={{marginRight: '5px'}} aria-hidden="true"></i>
                        <i className="fa fa-ellipsis-v wd-padding-20-right"  style={{marginRight: '5px'}} aria-hidden="true"></i>
                    </div>  
</Link>
                ))}


            </ul>
        </div>
        </div>        
        </>

);
}
export default Assignments;