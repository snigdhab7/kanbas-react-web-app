import KanbasNavigation from "./KanbasNavigation/KanbasNavigation";
function Kanbas() {
    console.log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&7")
    return (
    <div className="d-flex">
        <KanbasNavigation />
    <div>
    <h1>Kanbas Navigation</h1>
    </div>
    <div>
    <h1>Account</h1>
    <h1>Dashboard</h1>
    <h1>Courses</h1>
    </div>
    </div>
    );
    }
    export default Kanbas;
    